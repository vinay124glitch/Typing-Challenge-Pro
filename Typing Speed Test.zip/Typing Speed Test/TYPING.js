let timer;
let timeLeft = 60;
let started = false;
let currentText = "";

const inputArea = document.getElementById("input-area");
const textDisplay = document.getElementById("text-display");
const timerDisplay = document.getElementById("timer");
const resultDisplay = document.getElementById("result");
const timeSelect = document.getElementById("time-select");
const btnLetters = document.getElementById("btn-letters");
const btnWords = document.getElementById("btn-words");
const btnNumbers = document.getElementById("btn-numbers");
const progressBar = document.getElementById("progress-bar");

inputArea.addEventListener("input", () => {
  if (!started) return;
  updateLiveStats();
});

document.getElementById("theme-toggle").addEventListener("change", (e) => {
  document.body.classList.toggle("dark", e.target.checked);
});

function generateText(type) {
  const letters = "abcdefghijklmnopqrstuvwxyz";
  const numbers = "0123456789";
  const words = ["cat", "dog", "apple", "banana", "tree", "sky", "cloud", "run", "jump", "blue"];
  let result = "";

  if (type === "letters") {
    for (let i = 0; i < 50; i++) {
      result += letters[Math.floor(Math.random() * letters.length)] + " ";
    }
  } else if (type === "words") {
    for (let i = 0; i < 30; i++) {
      result += words[Math.floor(Math.random() * words.length)] + " ";
    }
  } else if (type === "numbers") {
    for (let i = 0; i < 40; i++) {
      result += numbers[Math.floor(Math.random() * numbers.length)] + " ";
    }
  }

  return result.trim();
}

function startRound(type) {
  let selectedTime = parseInt(timeSelect.value);
  timeLeft = selectedTime;
  progressBar.max = timeLeft;
  progressBar.value = timeLeft;
  inputArea.disabled = false;
  inputArea.value = "";
  resultDisplay.textContent = "";
  timerDisplay.textContent = `Time: ${timeLeft}s`;
  currentText = generateText(type);
  textDisplay.textContent = currentText;
  inputArea.focus();
  started = true;

  btnLetters.disabled = true;
  btnWords.disabled = true;
  btnNumbers.disabled = true;
  timeSelect.disabled = true;

  timer = setInterval(() => {
    timeLeft--;
    progressBar.value = timeLeft;
    timerDisplay.textContent = `Time: ${timeLeft}s`;
    updateLiveStats();
    if (timeLeft === 0) endTest();
  }, 1000);
}

function updateLiveStats() {
  const typedText = inputArea.value.trim();
  const correctChars = countCorrectChars(typedText, currentText);
  const accuracy = ((correctChars / currentText.length) * 100).toFixed(2);
  const wordsTyped = typedText.split(/\s+/).length;

  resultDisplay.innerHTML = `
    <p>Live WPM: ${wordsTyped}</p>
    <p>Live Accuracy: ${accuracy}%</p>
  `;
}

function countCorrectChars(typed, target) {
  let count = 0;
  for (let i = 0; i < typed.length; i++) {
    if (typed[i] === target[i]) count++;
  }
  return count;
}

function endTest() {
  clearInterval(timer);
  inputArea.disabled = true;
  updateLiveStats();
  started = false;

  const typedText = inputArea.value.trim();
  const correctChars = countCorrectChars(typedText, currentText);
  const accuracy = ((correctChars / currentText.length) * 100).toFixed(2);
  const wordsTyped = typedText.split(/\s+/).length;

  updateScoreboard(wordsTyped, accuracy);

  btnLetters.disabled = false;
  btnWords.disabled = false;
  btnNumbers.disabled = false;
  timeSelect.disabled = false;
}

function resetTest() {
  clearInterval(timer);
  inputArea.value = "";
  textDisplay.textContent = "";
  timerDisplay.textContent = `Time: ${timeSelect.value}s`;
  resultDisplay.textContent = "";
  inputArea.disabled = true;
  started = false;
  progressBar.value = timeSelect.value;

  btnLetters.disabled = false;
  btnWords.disabled = false;
  btnNumbers.disabled = false;
  timeSelect.disabled = false;
}

function updateScoreboard(wpm, accuracy) {
  let highWPM = parseInt(localStorage.getItem("highWPM") || "0");
  let highAccuracy = parseFloat(localStorage.getItem("highAccuracy") || "0");

  if (wpm > highWPM) localStorage.setItem("highWPM", wpm);
  if (accuracy > highAccuracy) localStorage.setItem("highAccuracy", accuracy);

  document.getElementById("high-wpm").textContent = localStorage.getItem("highWPM");
  document.getElementById("high-accuracy").textContent = localStorage.getItem("highAccuracy") + "%";
}

// Initialize scoreboard
updateScoreboard(0, 0);
    