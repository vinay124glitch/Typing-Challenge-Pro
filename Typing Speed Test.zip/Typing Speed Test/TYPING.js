let timer;
let timeLeft = 60;
let started = false;
let currentText = "";

const inputArea = document.getElementById("input-area");
const textDisplay = document.getElementById("text-display");
const timerDisplay = document.getElementById("timer");
const resultDisplay = document.getElementById("result");
const timeSelect = document.getElementById("time-select");
const btnLetters = document.getElementById("btn-letters");
const btnWords = document.getElementById("btn-words");
const btnNumbers = document.getElementById("btn-numbers");
const progressBar = document.getElementById("progress-bar");

inputArea.addEventListener("input", () => {
  if (!started) return;
  updateLiveStats();
});

document.getElementById("theme-toggle").addEventListener("change", (e) => {
  document.body.classList.toggle("dark", e.target.checked);
  if (e.target.checked) {
    if (!fallInterval) fallInterval = setInterval(drawFallingLetters, 50);
  } else {
    clearInterval(fallInterval);
    fallInterval = null;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  }
});

function generateText(type) {
  const letters = "abcdefghijklmnopqrstuvwxyz";
  const numbers = "0123456789";
  const words = ["cat", "dog", "apple", "banana", "tree", "sky", "cloud", "run", "jump", "blue"];
  let result = "";

  if (type === "letters") {
    for (let i = 0; i < 50; i++) {
      result += letters[Math.floor(Math.random() * letters.length)] + " ";
    }
  } else if (type === "words") {
    for (let i = 0; i < 30; i++) {
      result += words[Math.floor(Math.random() * words.length)] + " ";
    }
  } else if (type === "numbers") {
    for (let i = 0; i < 40; i++) {
      result += numbers[Math.floor(Math.random() * numbers.length)] + " ";
    }
  }

  return result.trim();
}

function startRound(type) {
  let selectedTime = parseInt(timeSelect.value);
  timeLeft = selectedTime;
  progressBar.max = timeLeft;
  progressBar.value = timeLeft;
  inputArea.disabled = false;
  inputArea.value = "";
  resultDisplay.textContent = "";
  timerDisplay.textContent = `Time: ${timeLeft}s`;
  currentText = generateText(type);
  textDisplay.textContent = currentText;
  inputArea.focus();
  started = true;

  btnLetters.disabled = true;
  btnWords.disabled = true;
  btnNumbers.disabled = true;
  timeSelect.disabled = true;

  timer = setInterval(() => {
    timeLeft--;
    progressBar.value = timeLeft;
    timerDisplay.textContent = `Time: ${timeLeft}s`;
    updateLiveStats();
    if (timeLeft === 0) endTest();
  }, 1000);
}

function updateLiveStats() {
  const typedText = inputArea.value.trim();
  const correctChars = countCorrectChars(typedText, currentText);
  const accuracy = ((correctChars / currentText.length) * 100).toFixed(2);
  const wordsTyped = typedText.split(/\s+/).length;

  resultDisplay.innerHTML = `
    <p>Live WPM: ${wordsTyped}</p>
    <p>Live Accuracy: ${accuracy}%</p>
  `;
}

function countCorrectChars(typed, target) {
  let count = 0;
  for (let i = 0; i < typed.length; i++) {
    if (typed[i] === target[i]) count++;
  }
  return count;
}

function endTest() {
  clearInterval(timer);
  inputArea.disabled = true;
  updateLiveStats();
  started = false;

  const typedText = inputArea.value.trim();
  const correctChars = countCorrectChars(typedText, currentText);
  const accuracy = ((correctChars / currentText.length) * 100).toFixed(2);
  const wordsTyped = typedText.split(/\s+/).length;

  updateScoreboard(wordsTyped, accuracy);

  btnLetters.disabled = false;
  btnWords.disabled = false;
  btnNumbers.disabled = false;
  timeSelect.disabled = false;
}

function resetTest() {
  clearInterval(timer);
  inputArea.value = "";
  textDisplay.textContent = "";
  timerDisplay.textContent = `Time: ${timeSelect.value}s`;
  resultDisplay.textContent = "";
  inputArea.disabled = true;
  started = false;
  progressBar.value = timeSelect.value;

  btnLetters.disabled = false;
  btnWords.disabled = false;
  btnNumbers.disabled = false;
  timeSelect.disabled = false;
}

function updateScoreboard(wpm, accuracy) {
  let highWPM = parseInt(localStorage.getItem("highWPM") || "0");
  let highAccuracy = parseFloat(localStorage.getItem("highAccuracy") || "0");

  if (wpm > highWPM) localStorage.setItem("highWPM", wpm);
  if (accuracy > highAccuracy) localStorage.setItem("highAccuracy", accuracy);

  document.getElementById("high-wpm").textContent = localStorage.getItem("highWPM");
  document.getElementById("high-accuracy").textContent = localStorage.getItem("highAccuracy") + "%";
}

// === Falling Letters Effect ===

const canvas = document.getElementById("falling-canvas");
const ctx = canvas.getContext("2d");
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

const characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
const charArray = characters.split("");
const fontSize = 18;
const columns = canvas.width / fontSize;

const drops = Array(Math.floor(columns)).fill(1);

function drawFallingLetters() {
  ctx.fillStyle = "rgba(0, 0, 0, 0.05)";
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  ctx.fillStyle = "#0F0";
  ctx.font = fontSize + "px monospace";

  for (let i = 0; i < drops.length; i++) {
    const text = charArray[Math.floor(Math.random() * charArray.length)];
    ctx.fillText(text, i * fontSize, drops[i] * fontSize);

    if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) {
      drops[i] = 0;
    }

    drops[i]++;
  }
}

let fallInterval = setInterval(drawFallingLetters, 50);

window.addEventListener("resize", () => {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
});
